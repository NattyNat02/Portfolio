This folder contains 3 documents:
	-Caluclator.js
		-JavaScript program for calculator functions
	-main.html
		-HTML Document for calculator layout
	-styl.css
		-Syle sheet for the webpage