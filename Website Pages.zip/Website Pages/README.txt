Changes since last Submission:
	-Added Text and Images to frames and articles on Experience Page
	-Added Table, Text and Images and new frames to Involvements Page
	-Added GIFS and Text to Interests Page


Things I still need to do:
	-Make Home Page Less Wordy
	-Adjust widths and heights so it adjust properly to window size changes
	-Make some slight color adjustments to certain text on the website(Skills and Organizaitons sections)
		



This folder contains the 5 webpages of my portfolio website.
The webpages are organized with the following hierarchy:
	1. Home Page- Most Important
	2. Experience Page
	3. Involvements Page
	4. Interests Page
	5. Contact Page- Least Important
	
HOME PAGE
	-Contains gneneral information about me (Name, School, Background)
		-Gives brief summaries of contents on other pages
		-links to other webpages

EXPERIENCE PAGE
	-Includes all of my work related skills and experiences
	-Peak Areas if Interest:
		-Education and Honors
		-Current Work Experience
		-Previous Work Experiences
		-Certifications
		-Projects
		-Skills(Technical and Soft)

INVOLVEMENTS PAGE
	-This page includes all of my extra cirricular involvements which I participate in 
		-Will also include a brief description of the organizations
	-Peak Areas of Interest:
		-Softball
		-School Organizaitons(FCA, Business Club, ISACA, SGA etc)
		-Volunteer Work

INTERESTS PAGE
	-Includes personal interests and hobbies
	-Can be deleted if needed

CONACT PAGE
	-Provides informaiton on how the user can contact me
	-Can be deleted if needed
		-Info would still be found on website, just either added on another page or as a part of the footer

Other Documents:
	-Natalie Myers Professional Headshot.jpg: image used in header
	-TechBackground.jpg: Background image for website
	-download2.png: magnifying glass background image for search bar 
	-gaming.gif: videogame controller gif on Home Page used to link to Interests page
	-Typing.gif: typing gif used on Home page to link to Experience Page
	-uiwSoftballLogo.png: softball logo used on home page to link to Involvements Page
	-Pitching Pic.JPG: Image for softball section on Involvements Page
	-UIWLogo.png: Image For Education section on Home Page
	(NEW IMAGES)
	-ON EXPERIENCE PAGE:
		-AEOP.png:Logo for AEOP Internship I participated in Summer 2019	
		-ApplianceWarehouse.png: Logo For Appliance Warehouse Project I worked on
		-AVS Lab Logo.png: Logo for AVS Lab that I work at
		-DonkeyCar: Logo for the software I worked with during my AEOP Internship
		-IdeaLabKids.jfif: Logo for the first company I worked for
	-ON INVOLVEMENTS PAGE:
		-Softball Headshot1.png: Image of my softball headshot for softball section
		-businessClubLogo.png: Logo for the UIW Business CLub that I am a member in
		-DeltaMuDelta.png: Logo for the Business Honor Society which I'm a member of
		-FCALogo.png: Logo for FCA which I am a Leader in
		-FoodBank Logo.png: Logo for the Food Bank which I volunteered at
		-halloweenLogo.png: A Halloween Logo to represent the FCA Halloween Candy Giveaway which I volunteered for
		-ISACAlogo.jfif: A logo for the ISACA organization which I'm a part of
		-MiracleLeague.jfif: A logo for Miracle League event which I volunteered to work
		-NSLSlogo.png: A logo for the honor society that I'm a member of
		-PetsAliveLogo.png: A logo for my time volunteering at PetsAlive 
		-SGALogo.jfif: A logo for the Student Government Association which I am a Senator for
		-specialOlympics.Logopng.png: A logo for the sepecial Olympics event which I volunteered for
	-ON INTERESTS PAGE:
		-animation.gif: A GIF representing my interest in aniamtion
		-binary.gif:A GIF representing my interest in all things computer technology
		-hands-sketching.gif:A GIF representing my interest in sketching
		-low-poly-3d.gif:A GIF representing my interest in 3D Modeling and 3D Animation
		-python.gif:A GIF representing my interest in programming
		-Switch.gif.crdownload:A GIF representing my interest in videogames

