//horizontal velocity 
let directionX = 10;
//horizontal velocity 
let directionY = 0;

//Est X & Y coordiates for food
let foodX;
let foodY;

//Sets score to 0 when game starts
let score = 0;

let changeDirection = false;

const snakeBoard = document.getElementById("snakeboard");
const snakeBoard_ctx = snakeBoard.getcontext('2D');

//start game 
main();

function main(){
    drawFood();
    drawSnake();
    moveSnake();
    clearBoard();
    changeDirection = false;

}

function clearBoard(){
    //select the color to fill the drawing
    snakeBoard_ctx.fillstyle = black;
    snakeBoard_ctx.fillRect(0,0,snakeBoard.width,snakeBoard.height);
}

function drawSnake(){
    snake.forEach(drawSnakepart);
}

function drawFood(){
    snakeBoard_ctx.fillstyle = 'lightgreen';
    snakeBoard_ctx.strokestyle = 'darkgreen';
    snakeBoard_ctx.fillRect(foodX, foodY, 10, 10);
    snakeBoard_ctx.strokeRect(foodX, foodY, 10, 10);
}

function drawSnakepart(snakePart){

}

let snake = [
    {x:200, y:200},
    {x:190, y:200},
    {x:180, y:200},
    {x:170, y:200},
    {x:160, y:200},
]